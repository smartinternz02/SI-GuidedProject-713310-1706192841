<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Amazon MusicStream millionsof songsAmaz_b96c2e</name>
   <tag></tag>
   <elementGuidId>77f1bc48-995b-465c-a7df-51633cbccdde</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='navFooter']/div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.navFooterLine.navFooterLinkLine.navFooterDescLine</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3ba8a690-b69a-4d51-ad73-490ca6fd0f94</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navFooterLine navFooterLinkLine navFooterDescLine</value>
      <webElementGuid>6e824d38-77c1-45a5-bf5f-14243401a8f0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>navigation</value>
      <webElementGuid>227f3838-4a7d-4827-b611-825e22a79530</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>More on Amazon</value>
      <webElementGuid>4f0a0dcf-44b0-4e03-b2fd-828f04996da1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
      
Amazon MusicStream millionsof songs
Amazon AdsReach customerswherever theyspend their time
6pmScore dealson fashion brands
AbeBooksBooks, art&amp; collectibles
ACX Audiobook PublishingMade Easy
Sell on AmazonStart a Selling Account
Amazon BusinessEverything ForYour Business
 

AmazonGlobalShip OrdersInternationally
Home ServicesExperienced ProsHappiness Guarantee
Amazon Web ServicesScalable CloudComputing Services
AudibleListen to Books &amp; OriginalAudio Performances
Box Office MojoFind MovieBox Office Data
GoodreadsBook reviews&amp; recommendations
IMDbMovies, TV&amp; Celebrities
 

IMDbProGet Info EntertainmentProfessionals Need
Kindle Direct PublishingIndie Digital &amp; Print PublishingMade Easy

Prime Video DirectVideo DistributionMade Easy
ShopbopDesignerFashion Brands
Woot!Deals and Shenanigans
ZapposShoes &amp;Clothing
RingSmart HomeSecurity Systems

 

 

eero WiFiStream 4K Videoin Every Room
BlinkSmart Securityfor Every Home

Neighbors App  Real-Time Crime&amp; Safety Alerts

Amazon Subscription BoxesTop subscription boxes – right to your door
PillPackPharmacy Simplified
 


    
  </value>
      <webElementGuid>d554200f-febe-4f0b-8fc3-2791a1cd13cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navFooter&quot;)/div[@class=&quot;navFooterLine navFooterLinkLine navFooterDescLine&quot;]</value>
      <webElementGuid>ba6d7631-d510-43ed-ab9e-637a5ff64bf5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='navFooter']/div[4]</value>
      <webElementGuid>c2640fd4-5d28-4c69-8e40-d7ed83d78f4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[4]</value>
      <webElementGuid>d9c873e0-0b89-4b96-8a67-22fcbfda52ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
      
Amazon MusicStream millionsof songs
Amazon AdsReach customerswherever theyspend their time
6pmScore dealson fashion brands
AbeBooksBooks, art&amp; collectibles
ACX Audiobook PublishingMade Easy
Sell on AmazonStart a Selling Account
Amazon BusinessEverything ForYour Business
 

AmazonGlobalShip OrdersInternationally
Home ServicesExperienced ProsHappiness Guarantee
Amazon Web ServicesScalable CloudComputing Services
AudibleListen to Books &amp; OriginalAudio Performances
Box Office MojoFind MovieBox Office Data
GoodreadsBook reviews&amp; recommendations
IMDbMovies, TV&amp; Celebrities
 

IMDbProGet Info EntertainmentProfessionals Need
Kindle Direct PublishingIndie Digital &amp; Print PublishingMade Easy

Prime Video DirectVideo DistributionMade Easy
ShopbopDesignerFashion Brands
Woot!Deals and Shenanigans
ZapposShoes &amp;Clothing
RingSmart HomeSecurity Systems

 

 

eero WiFiStream 4K Videoin Every Room
BlinkSmart Securityfor Every Home

Neighbors App  Real-Time Crime&amp; Safety Alerts

Amazon Subscription BoxesTop subscription boxes – right to your door
PillPackPharmacy Simplified
 


    
  ' or . = '
    
      
Amazon MusicStream millionsof songs
Amazon AdsReach customerswherever theyspend their time
6pmScore dealson fashion brands
AbeBooksBooks, art&amp; collectibles
ACX Audiobook PublishingMade Easy
Sell on AmazonStart a Selling Account
Amazon BusinessEverything ForYour Business
 

AmazonGlobalShip OrdersInternationally
Home ServicesExperienced ProsHappiness Guarantee
Amazon Web ServicesScalable CloudComputing Services
AudibleListen to Books &amp; OriginalAudio Performances
Box Office MojoFind MovieBox Office Data
GoodreadsBook reviews&amp; recommendations
IMDbMovies, TV&amp; Celebrities
 

IMDbProGet Info EntertainmentProfessionals Need
Kindle Direct PublishingIndie Digital &amp; Print PublishingMade Easy

Prime Video DirectVideo DistributionMade Easy
ShopbopDesignerFashion Brands
Woot!Deals and Shenanigans
ZapposShoes &amp;Clothing
RingSmart HomeSecurity Systems

 

 

eero WiFiStream 4K Videoin Every Room
BlinkSmart Securityfor Every Home

Neighbors App  Real-Time Crime&amp; Safety Alerts

Amazon Subscription BoxesTop subscription boxes – right to your door
PillPackPharmacy Simplified
 


    
  ')]</value>
      <webElementGuid>27778bb0-4572-492b-8b58-1b8dd1b8076b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
